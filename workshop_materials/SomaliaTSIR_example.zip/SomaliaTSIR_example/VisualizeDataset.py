""" VisualizeDataset.py

Basic 3 panel plot of the synthetic, single campaign, Somalia dataset """
import sys
sys.path.append("..\\")

## Standard stuff
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import methods

def axes_setup(axes):
	axes.spines["left"].set_position(("axes",-0.025))
	axes.spines["top"].set_visible(False)
	axes.spines["right"].set_visible(False)
	return

if __name__ == "__main__":

	## Get the dataset from CSV
	df = pd.read_csv("somalia_synthetic_dataset.csv",
					 index_col=0,
					 parse_dates=[0],date_parser=pd.to_datetime)

	## Set up a plot
	fig, axes = plt.subplots(3,1,figsize=(12,10),
								 sharex=True)

	## Make the cases panel
	axes_setup(axes[0])
	axes[0].grid(color="grey",alpha=0.2)
	axes[0].plot(df["cases"],color="xkcd:red wine",lw=4)
	axes[0].set_ylim((0,1700))
	axes[0].set_ylabel("Semi-monthly cases",fontsize=20)
	axes[0].text(0.01,0.97,"Cases",
				 horizontalalignment="left",verticalalignment="top",
				 color="xkcd:red wine",fontsize=32,
				 transform=axes[0].transAxes)
	
	## Make the births panel
	axes_setup(axes[1])
	axes[1].grid(color="grey",alpha=0.2)
	axes[1].plot(df["births"],lw=4,color="xkcd:slate blue")
	axes[1].set_ylabel("Semi-monthly births",fontsize=20)
	axes[1].text(0.01,0.97,"Births",
				 horizontalalignment="left",verticalalignment="top",
				 color="xkcd:slate blue",fontsize=32,
				 transform=axes[1].transAxes)
	
	## And a vaccination panel
	axes_setup(axes[2])
	axes[2].grid(color="grey",alpha=0.2)
	axes[2].plot(df.loc["2019-01-01":,"mcv1"],lw=4,color="xkcd:grape",label="MCV1")
	axes[2].plot(df.loc[:"2019-01-01","mcv1"],lw=4,color="xkcd:grape",ls="dashed")
	axes[2].set_ylabel("Semi-monthly doses",fontsize=20)
	axes[2].set_ylim((0,None))
	y0, y1 = axes[2].get_ylim()

	## Add the SIA
	sia_cal = df.loc[df["sia"] !=0]
	max_doses = sia_cal["sia"].max()
	for t, r in sia_cal.iterrows():
		axes[2].axvline(t,ymax=0.333*r.loc["sia"]/max_doses,
						color="k",lw=2)
		label = "{0:0.1f}M".format(r.loc["sia"]/1e6)
		axes[2].text(t,1.015*0.333*(y1-y0)*r.loc["sia"]/max_doses,label,
					horizontalalignment="center",verticalalignment="bottom",
					color="k",fontsize=16)
	axes[2].text(0.01,0.97,"Vaccines",
				 horizontalalignment="left",verticalalignment="top",
				 color="xkcd:grape",fontsize=32,
				 transform=axes[2].transAxes)

	## Finish up
	fig.tight_layout()
	fig.savefig("_plots\\dataset.png")
	plt.show()