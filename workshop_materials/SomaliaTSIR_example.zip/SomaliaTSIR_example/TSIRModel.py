""" TSIRModel.py

Fit a basic TSIR model to the dataset to estimate campaign impact. """
import sys
sys.path.append("..\\")

## Standard stuff
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import methods

## For model evaluation
from sklearn.metrics import r2_score
colors = ["#375E97","#FB6542","#FFBB00","#5ca904","xkcd:saffron"]

def axes_setup(axes):
	axes.spines["left"].set_position(("axes",-0.025))
	axes.spines["top"].set_visible(False)
	axes.spines["right"].set_visible(False)
	return

def low_mid_high(samples,axis=0):
	l0 = np.percentile(samples,2.5,axis=axis)
	h0 = np.percentile(samples,97.5,axis=axis)
	l1 = np.percentile(samples,25.,axis=axis)
	h1 = np.percentile(samples,75.,axis=axis)
	m = samples.mean(axis=axis)
	#m = np.percentile(samples,50.,axis=0) 
	return l0, l1, m, h1, h0

def fit_quality(data,samples,verbose=True):

	## Compute a summary
	l0,l1,m,h1,h0 = low_mid_high(samples)

	## Compute scores
	score = r2_score(data,m)
	score50 = len(data[np.where((data >= l1) & (data <= h1))])/len(m)
	score95 = len(data[np.where((data >= l0) & (data <= h0))])/len(m)
	if verbose:
		print("R2 score = {}".format(score))
		print("With 50 interval: {}".format(score50))
		print("With 95 interval: {}".format(score95))
	
	return score, score50, score95

def LinearRegression(X,Y):

	""" Linear regression, this implementation computes
	the estimator and covariance matrix based on marginalized variance. 

	NB: X is assumed to be an array with shape = (num_data points, num_features) """

	## Get the dimensions
	num_data_points = X.shape[0]
	try:
		num_features = X.shape[1]
	except:
		num_features = 1
		X = X.reshape((num_data_points,1))

	## Compute the required matrix inversion
	## i.e. inv(x.T*x), which comes from minimizing
	## the residual sum of squares (RSS) and solving for
	## the optimum coefficients.
	xTx_inv = np.linalg.inv(np.dot(X.T,X))

	## Now use that matrix to compute the optimum coefficients
	## and their uncertainty.
	beta_hat = np.dot(xTx_inv,np.dot(X.T,Y))

	## Compute the estimated variance in the data points
	residual = Y - np.dot(X,beta_hat)
	RSS = (residual)**2
	var = RSS.sum(axis=0)/(num_data_points - 1)

	## Then the uncertainty (covariance matrix) is simply a 
	## reapplication of the inv(x.T*x):
	beta_var = var*xTx_inv

	## Reshape the outputs
	if num_features > 1:
		beta_hat = beta_hat.reshape((num_features,))
	else:
		beta_hat = beta_hat[0]
		beta_var = beta_var[0,0]

	return beta_hat, beta_var, residual

def ReportingRateRegr(cases,births,visualize=False):

	## Compute the features and response
	response = np.cumsum(births.values[:-1])
	features = np.cumsum(cases.values[1:]).reshape(-1,1)

	## Compute the MAP estimate
	rho, rho_var, rr_resid = LinearRegression(features,response)

	## Compute the reporting rate estimate
	r = 1./rho
	r_var = rho_var/(rho**4)

	if visualize:
		fig, axes = plt.subplots(figsize=(8,7))
		axes_setup(axes)
		axes.plot(response,color="k")
		axes.plot(rho*features,color="xkcd:red wine")
		axes.plot(rr_resid,color='C0')
		fig.tight_layout()

	return rho, rho_var, rr_resid, r, r_var

def HiddenStateRecon(cases,births,rho):

	## Calculate It estimate
	I_t = rho*(cases.values+1.)-1.

	## compute the residual
	Z_t = np.zeros(I_t.shape)
	Z_t[1:] = np.cumsum(births.values[:-1])-np.cumsum(I_t[1:]) 

	return I_t, Z_t

def TransmissionRegression(df,Z_t,I_t,periodicity=24):

	""" Transmission regression in the classic TSIR.

	df here is the df containing adj_births, cases, and SIAs for the region being modelled. """

	## Set up the basic feature matrix and response vector, Nxp and (N,) respectively.
	## These are the same as the basic TSIR model, found in the tsir.py class.
	N = len(df)-1
	p = periodicity+2
	X = np.zeros((N,p))
	Y = np.log(I_t[1:])
	X[:,:periodicity] = np.vstack((int(N/periodicity)+1)*[np.eye(periodicity)])[0:N]
	X[:,periodicity] = np.log(I_t[:-1])
	X[:,periodicity+1] = Z_t[:-1]

	## Compute the regression - don't standardize for log linear in the same
	## way as implemented above.
	params, params_var, residual = LinearRegression(X,Y)

	## Compute the sample variance
	RSS = (residual)**2
	var = RSS.sum(axis=0)/N

	## Compute the standard error in the betas via taylor series
	S0 = 1./params[periodicity+1]
	sig2s = np.diag(params_var)
	sig2 = sig2s[:periodicity] + sig2s[periodicity+1]/(S0**2)
	t_sig = np.exp(params[:periodicity])*np.sqrt(sig2)/S0

	## Compute some highlevel things we need for model testing, sampling, etc
	transmission_model = {"params":params,
					      "params_var":params_var,
						  "S0":1./params[periodicity+1],
						  "S0_std":np.sqrt(params_var[periodicity+1,periodicity+1])/(params[periodicity+1]**2),
						  "t_beta":np.exp(params[:periodicity])*params[periodicity+1],
						  "t_beta_sig":t_sig,
						  "alpha":params[periodicity],
						  "alpha_std":np.sqrt(np.diag(params_var)[periodicity]),
						  "std_logE":np.sqrt(var),
						  "periodicity":periodicity}

	return transmission_model

def NegLogPosterior(mu,df,
					epsilon=0.85):

	## Create vaccine adjusted births
	adj_births = df["births"] - epsilon*df["mcv1"] - mu*df["sia"]

	## Fit the model with these SIA efficacies
	rho, _, rr_resid, _, _ = ReportingRateRegr(df["cases"],adj_births)
	I_t, Z_t = HiddenStateRecon(df["cases"],adj_births,rho)
	transmission_model = TransmissionRegression(df,Z_t,I_t)

	## Compute the estimate of the negative log posterior distribution
	## over mu.
	return np.log(np.sum(rr_resid**2)) + (len(df)-1)*np.log(transmission_model["std_logE"])

def SampleTSIR(df,model,num_samples=10000):

	""" Sample the TSIR model without importation and spatial correlation. 
	df is the province dataframe with sia, Z_t, and I_t. model is the dictionary composed during 
	model fitting above. """

	## Hyper parameters
	n_steps = len(df)
	std_logE = model["std_logE"]

	## Allocate the appropriate storage
	samples = np.zeros((2,num_samples,n_steps))

	## Set up the initial conditions, accounting for importation
	samples[1,:,0] = df["I_t"].values[0]
	samples[0,:,0] = model["S0"] + df["Z_t"].values[0]

	## Loop through time
	for i in range(1,n_steps):
		
		## Time of year for seasonality
		time_in_period = i % model["periodicity"]

		## And the one step projection
		lam = model["t_beta"][time_in_period-1]*(samples[0,:,i-1])*((df["I_t"].values[i-1])**model["alpha"])

		## Sample for new infecteds in both cases
		I_ts = lam*np.exp(std_logE*np.random.normal(size=(num_samples,)))

		## Update predictions and residuals
		samples[1,:,i] = I_ts
		samples[0,:,i] = (samples[0,:,i-1]+df["adj_births"].values[i-1]-I_ts)

		## Take care of negatives (This happens for large std_logE, and this ensures
		## stability in that case).
		samples[1,samples[1,:,i] < 0,i] = 0.

	return samples

if __name__ == "__main__":

	## Get the dataset from CSV
	df = pd.read_csv("somalia_synthetic_dataset.csv",
					 index_col=0,
					 parse_dates=[0],date_parser=pd.to_datetime)
	print(df)

	## Set up candidate mu's
	mus = np.linspace(0,0.3,250)
	vax_effic = 0.85

	## Fit and test
	cost_func = np.zeros(mus.shape)
	for i, mu in enumerate(mus):
		NLP = NegLogPosterior(mu,df,
							  epsilon=vax_effic)
		cost_func[i] = NLP

	## Visualize the result
	print("\nBest fit model is:")
	pr_mu = np.exp(-cost_func + np.min(cost_func))
	pr_mu = pr_mu/(pr_mu.sum())
	exp_mu = np.sum(mus*pr_mu)
	var_mu = np.sum(pr_mu*(mus-exp_mu)**2)
	std_mu = np.sqrt(var_mu)
	best_mu = exp_mu
	print("Exp mu = {} +/- {}".format(exp_mu,std_mu))
	fig, axes = plt.subplots(figsize=(10,8))
	axes_setup(axes)
	axes.grid(color="grey",alpha=0.2)
	axes.plot(mus,pr_mu,color="k",lw=3)
	axes.set(ylabel="Posterior distribution",
			 xlabel=r"$\mu$, SIA efficacy")
	fig.tight_layout()
	fig.savefig("_plots\\posterior_estmate.png")

	## Evaluate the best fit model
	df["adj_births"] = df["births"] - vax_effic*df["mcv1"] - best_mu*df["sia"]
	rho, rho_var, rr_resid, rr, rr_var = ReportingRateRegr(df["cases"],df["adj_births"],visualize=True)
	I_t, Z_t = HiddenStateRecon(df["cases"],df["adj_births"],rho)
	model = TransmissionRegression(df,Z_t,I_t)
	df["Z_t"] = Z_t
	df["I_t"] = I_t
	print("Reporting rate = {}".format(rr))
	print("S0 = {}".format(model["S0"]))
	print("alpha = {}".format(model["alpha"]))
	print("std_logE = {}".format(model["std_logE"]))

	## Sample the model
	samples = SampleTSIR(df,model)

	## Sample to get estimates of observed cases
	model_cases = np.random.binomial(np.round(samples[1,:,:]).astype(int),
									 p=rr)
	
	## Test the goodness of fit
	print("\nGoodness of fit to cases (short term):")
	fit_quality(df["cases"].values,model_cases)

	## Make it all per pop
	#samples = 100*samples/(df["population"].values[None,None,:])

	## Summarize the result
	short_low, _, short_mid, _, short_high = low_mid_high(samples,axis=1)
	short_c_low, _, short_c_mid, _, short_c_high = low_mid_high(model_cases)

	## Plot the results
	fig, axes = plt.subplots(2,1,sharex=False,figsize=(14,7))
	for ax in axes:
		axes_setup(ax)
	axes[0].fill_between(df.index,short_c_low,short_c_high,
						 alpha=0.4,facecolor="grey",edgecolor="None")
	axes[0].plot(df.index,short_c_mid,color="grey",lw=3,label="Model fit")
	axes[0].plot(df.index,df["cases"],color="k",ls="None",
				 marker=".",markerfacecolor="k",markeredgecolor="k",markersize=10,
				 label="Reported cases")
	axes[0].set_ylim((0,None))
	axes[0].set_ylabel("Measles cases",color="grey",labelpad=15)
	axes[0].tick_params(axis="y",colors="grey")
	handles, labels = axes[0].get_legend_handles_labels()
	axes[0].legend(handles[::-1],labels[::-1],
				   frameon=False,fontsize=18,loc=2)

	## Plot the susceptibility panel
	axes[1].spines["left"].set_color(colors[0])
	axes[1].fill_between(df.index,short_low[0],short_high[0],
						 alpha=0.3,facecolor=colors[0],edgecolor="None")
	axes[1].plot(df.index,short_mid[0],color=colors[0],lw=3)
	axes[1].set_ylabel("Susceptibility",color=colors[0])
	axes[1].tick_params(axis="y",colors=colors[0])
	fig.tight_layout()
	fig.savefig("_plots\\model_inference.png")

	plt.show()
