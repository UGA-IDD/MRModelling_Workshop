################################################################################
#Install packages
################################################################################
#
meas <- read.csv("meas.csv")             # read the London measles time series

# fit a spline to the cumulative cases and births
cum.reg = smooth.spline(cumsum(meas$B), cumsum(meas$London), df=5)  # fit a smothing spline, which implis that reporting rate is not constant over time
D = - resid(cum.reg)                     #the residuals, which give the reconstructed susceptibles, up to a constant

#plot the cumulative cases and births
plot(cumsum(meas$B), cumsum(meas$London), type="l", xlab="Cumulative births", ylab="Cumuative incidence")
lines(cum.reg)       # add the fitted spline
abline(a=0,b=1)      # compare to perfect reporting assumption
################################################################################
#Stop: here we've fit a spline to the relation between cumulative incidence and 
# cumulative births, which allows for a non-constant reporting rate. The reporting 
# rate is then the first derivative of that spline. 
################################################################################
rr = predict(cum.reg, deriv = 1)$y  # time varying reporting rate from spline
summary(rr)                         # summarize reporting rate
plot(1:546,rr,ylab = "reporting rate", xlab = "biweek")     # plot the reporting rate

#Correct incidence and residuals for under reporting
Ic = meas$London/rr                 # divide the observed cases in each timestep by the reporting rate for that time step
Dc = D/rr                           # scale the residuals

######################################
# Set up 
seas = rep(1:26, 21)[1:545]          # create indices for the seasonality; this is a vector indicating which biweek each time step falls in
lInew = log(Ic[2:546])               # log Incidence in time T
lIold = log(Ic[1:545])               # log Incidence in time T-1; one index earlier than lInew
Dold = Dc[1:545]                     # residual in time T-1

######################################
#
N = 3300000                               # population size for London, assumed to be constant over this time (is this realistic?)
Smean = seq(0.02, 0.2, by = 0.001) * N    # a range of candidate values for the mean number susceptible (note that since measles is endemic, we would expect thsi proportion to be low)
offsetN = rep(-log(N), 545)               # log population size which will be used in the glm implementation of the fitting: see Chapter 7 of Bjornstad book for more detail


######################################
# Profile over Smean
# 1. We will fix values of Smean (mean number susceptible) and fit the remaining parameters
# 2. Then we will compare the best fit for each candidate value of Smean
# 3. Then we will take the estimate of Smean as the one that results in the best fit after fitting all other paramters

llik = rep(NA, length(Smean))             # storage for the log likelihood, one storage spot for each value of Smean
for(i in 1:length(Smean)){                # loop over all possible values of Smean
  lSold = log(Smean[i] + Dold)            # estimate of log susceptibles: this is the mean number plus the time specific residuals
  glmfit = glm(lInew ~ -1 + as.factor(seas) + lIold + offset(lSold + offsetN))     # fit using call to glm() (see Chapter 7 in Bjornstad for further explanation, this is equivalent to implementaiton from Niket)
  llik[i] = glmfit$deviance / 2           # record the negative log likelihood of the fit
}
par(mfrow=c(1,1))
plot(Smean/3.3E6, llik, ylim=c(min(llik), 25),xlab="Sbar", ylab="Neg log-lik")  # plot the log likelihood for all values of Smean

################################################################################
#Stop: We want the value of Smean with the highest likelihood OR the lowest negative log likelihood. Which value looks best?
# below we will use the call "which(llik==min(llik))" to identify which value of Smean is the lowest
################################################################################

######################################
# Redo fit only at the at best vlaue Smean -- Smean[which(llik==min(llik))]
lSold = log(Smean[which(llik==min(llik))] + Dold)     # as above, reconstruct susceptibles
glmfit = glm(lInew ~ -1 + as.factor(seas) + lIold + offset(lSold + offsetN))  # fit with glm()

Smean[which.min(llik)]/3300000       # Value of the best fit of mean proportion susceptible (note this is divided by total population to be a proportion) 
glmfit$coef[27]                      # Value of the bst fit of the exponent parameter alpha

################################################################################
#Stop: Does the fitted proportion susceptible make sense? What would this suggest about the scale of R0?
################################################################################

################################################################################
# this commented section of code will do the same fit as above using the optim() function 
# which 
################################################################################
# hand code the Finkenstadt and Grenfell TSIR model with least squares
# fit.fx<-function(par,vecs,Smean){
#   # This function calculates the likelihood for the log-linear model in Finkenstadt and Grenfell
#   #
#   T <- vecs$T                             # maximum time
#   beta<-rep(par[1:26],21)[1:(T-1)]        # indices for the biweeks
#   a1<-par[27]                             # alpha parameter
#   expect<-log(vecs$I[2:T])                # lot incidence at time t+1
#   obs<-log(beta) + a1*log(vecs$I[1:(T-1)]) - log(N) + log(vecs$D[1:(T-1)] + Smean) # statement of the expected log incidence at time t+1; this should follow from Niket's presentation
# 
#   out<-sum((expect-obs)^2)                # calculate the sum of squared difference between the log observed cases adn the log predicted cases
# }
# 
# # susceptible reconstruction as above
# cum.reg = smooth.spline(cumsum(meas$B), cumsum(meas$London), df=5)      # fit a smoothing spline to estimate the reporting rate
# D = - resid(cum.reg)                     #the residuals                 # take the residuals to reconstruct Susceptibles
# N = 3300000                                                             # total population size
# Smean = seq(0.02, 0.2, by = 0.001) * N                                  # candidate values of the susceptible population
# 
# #input covariates                                                       # create a list of input values
# vecs <- list(
#   I = meas$London,                                                      # the observed time series
#   D = D,                                                                # the residuals (for suscpetible reconstruction)
#   T = 546                                                               # number of time series
# )
# 
# #profile over the Smean
# SSE = rep(NA, length(Smean))                                            # storage for the sum of squared error, SSE
# for(i in 1:length(Smean)){                                              # implement for each value of Smean
#   par <- c(rep(26,26),.95)                                              # initial parameter values to start the search
#   SSE[i] <- optim(par,fit.fx,par,vecs,Smean=Smean[i])$value             # optimize for transmission and alpha parameters, conditional on Smean value
# }
# Smean[which.min(SSE)]/3300000    # this is the best fit proportion susceptible. How does this compare to the fit from the glm()?
# #refit at the best Smean
# fit <- optim(par,fit.fx,par,vecs,Smean=Smean[which.min(SSE)])           # refit at the best fit value of Smean
# 
# fit$par[27]       # this is the fitted alpha parameter. How does this compare to toe fit from glm()
# fit$par[1:26]     # these are the fitted seasonal transmission parameters which you can compare against the values from the glm()


################################################################################
# plot confidence bounds on seasonality
 
beta=exp(glmfit$coef[1:26])                                   # best fit value of seasonal transmission (note glm() fits the log of this parameter, we use exp() put on natural scale)
ubeta=exp(glmfit$coef[1:26] + summary(glmfit)$coef[1:26, 2])  # upper bound fit value of seasonal transmission (note glm() fits the log of this parameter, we use exp() put on natural scale)
lbeta=exp(glmfit$coef[1:26] - summary(glmfit)$coef[1:26, 2])  # lower bound fit value of seasonal transmission (note glm() fits the log of this parameter, we use exp() put on natural scale)

matplot(x=c(1:26), y=cbind(beta,ubeta,lbeta) ,xlab="Biweek", ylab=expression(beta),pch=NA)    # create a plotting window 
points(x=c(1:26), y=beta, pch=19)                                                             # plot mean beta   
points(x=c(1:26), y=ubeta, pch="-")                                                           # plot upper bound beta
points(x=c(1:26), y=lbeta, pch="-")                                                           # plot lower bound beta
segments(x0=1:26,y0=lbeta,x1=1:26,y1=ubeta,lty=1,col=1)                                       # plot vertical bars for confidence bounds

################################################################################
# Simulate the TSIR model
# A simulation function to implement a Chain binomial simulation based on the fitted parameters
SimTsir2=function(beta, alpha, B, N, inits = list(Snull = 0, Inull = 0), type = "det"){ 
  # beta = a vector of betas, length is in the number of time steps within a year; 26 
  # alpha = scalar value of exponent
  # B = vector of numbers of births in each time step, length should equal beta
  # N = vector of population sizes, length shoudl equal beta
  # inits = initial values 
  # type = stochastic or deterministic simulation
  
  type = charmatch(type, c("det", "stoc"),nomatch = NA)           # do you want a deterministic or stochastic simulation
  if(is.na(type)){                                                # give an error if the input statement is wrong
    stop("method should be \"det\", \"stoc\"")
  }
  IT = length(B)                     # length of time to simulate is the length of timesteps in the births input 
  s = length(beta)                   # length of the seasonal transmission rates; here we're using 26 bi-weeks
  lambda = rep(NA, IT)               # storage for the expected new cases
  I = rep(NA, IT)                    # storage for the cases
  S = rep(NA, IT)                    # storage for the susceptibles
  I[1] = inits$Inull                 # initial number infected
  lambda[1] = inits$Inull            # initial new cases
  S[1] = inits$Snull                 # initial number susceptible 
  
  for(i in 2:IT) {                   # loop over all time steps
    lambda[i] = beta[((i - 2) %% s) + 1] *S[i-1] * (I[i-1]^alpha)/N    # calculate force of infection due to transmission, S, and I
    if(type == 2) {                                                    # if stochastic simulation, make a random draw of new cases
      I[i] = rpois(1, lambda[i]) 
    }
    if(type == 1) {                                                    # if deterministic, new case equal lambda
      I[i] = lambda[i]
    }
    S[i] =S[i - 1] + B[i] - I[i]                                       # add births and remove infections from susceptibles
  }
  return(list(I = I, S = S))                                           # return the time series of I and S
}

################################################################################
# Implement a stochastic realization fo the TSIR fit at the fitted parameter values from above
################################################################################
sim=SimTsir2(beta=exp(glmfit$coef[1:26]), alpha=glmfit$coef[27], B=meas$B, N=N, inits=list(Snull=Dc[1]+ Smean[which(llik==min(llik))], Inull=Ic[1]),type="stoc")
plot(sim$I, type="l", ylim=c(0, max(Ic)), ylab="Incidence", xlab="Biweek",lwd=2)
lines(exp(lInew),type="b", col="red", pch=20)
legend("topleft", legend=c("simulated", "Observed"), lty=c(1,1), lwd=c(2,1),
       pch=c(NA,20), col=c("black", "red"))

################################################################################
# Stop: Note that this doesn't match as well as the fit that Niket presented, this is because
#       the fit is condidtion on the previous time step (one-step ahead projection). This simulation 
#       starts at time 0 and projects the entire time series  
################################################################################

################################################################################
# Now add more random realizations of the time series
# note that is the same call as above, because this is a stochastic simulation, each realization will be different
for(i in 1:500){
  sim=SimTsir2(beta=exp(glmfit$coef[1:26]), alpha=glmfit$coef[27], B=meas$B, N=N, inits=list(Snull=Dc[1]+ Smean[which(llik==min(llik))], Inull=Ic[1]),type="stoc")
  lines(sim$I, type="l",lwd=2, col = rgb(0,0,0,.1))           # plot using a semi-transparent line so we can still see the data
 }
################################################################################
# Stop: Note that the lines are darkest at the most common trajectory, but there are occational light grey trajectories 
#       that are further away
################################################################################


###############################################################################
# This is an artificial case for the purposes of teaching, but now we can simulate 
# what might have happened if measles vaccination was introduced in the 547th biweek (about 1965)
# We can simulate this as a reduction in the effective birth rate. Recall our discussion about the 
# different ways to represent vaccination in model. The method we are using here is the simplest
# and the least realistic. births were increasign from 1955-1964, so we'll assume that this trend 
# continues and also assume that vaccination begins low and increases linearly fro 260 biweeks (10 years).
###############################################################################
# add vaccination by reducing B
London_births <- seq(2442,3000,length=260)            # create a new vector of for the next 10 years assuming the trend continues
vaccination_coverage <- seq(.05,.95,length=260)        # assume coverage is introduced at 5% and increases linearly over 10 years until 95%

plot(1:260, vaccination_coverage, ylab = "time in biweeks", xlab = "vaccination coverage")
################################################################################
# Stop: Is this a reasonable assumption for how vaccination coverage will change over time?
#       What are alternative scenarios for how vaccination could be introduced? 
################################################################################


London_births_vacc <- c(meas$B,London_births * (1-vaccination_coverage))       # for the time from 547-807, 

sim=SimTsir2(beta=exp(glmfit$coef[1:26]), alpha=glmfit$coef[27], B=London_births_vacc, N=N, inits=list(Snull=Dc[1]+ Smean[which(llik==min(llik))], Inull=Ic[1]),type="stoc")
plot(sim$I, type="l", ylim=c(0, max(Ic)), ylab="Incidence", xlab="Biweek",lwd=2)
lines(exp(lInew),type="b", col="red", pch=20)
legend("topleft", legend=c("simulated", "Observed"), lty=c(1,1), lwd=c(2,1),
       pch=c(NA,20), col=c("black", "red"))

#######################################################################################
# Stop: Notice how cases decrease as vaccinatin increases 
#######################################################################################
# Now we would like to project how many cases were averted. To do this we need to project 
# both the future WITHOUT vaccination and the fututre WITH vaccination
# 
# Without vaccination
London_births_non <- c(meas$B,London_births)
nsim <- 1000                        # number to simulate
simI_non <- matrix(NA,806,nsim)         # storage for each simulation
for(i in 1:nsim){                    # simulate nsim realizations
  sim=SimTsir2(beta=exp(glmfit$coef[1:26]), alpha=glmfit$coef[27], B=London_births_non, N=N, inits=list(Snull=Dc[1]+ Smean[which(llik==min(llik))], Inull=Ic[1]),type="stoc")
  simI_non[,i] <- sim$I                 # store the simualted time series
}
matplot(simI_non, type="l",lty=1,lwd=2, col = rgb(1,0,0,.1))           # plot using a semi-transparent line so we can still see the data

#With vaccination
London_births_vacc <- c(meas$B,London_births * (1-vaccination_coverage))
nsim <- 1000                        # number to simulate
simI_vacc <- matrix(NA,806,nsim)         # storage for each simulation
for(i in 1:nsim){                    # simulate nsim realizations
  sim=SimTsir2(beta=exp(glmfit$coef[1:26]), alpha=glmfit$coef[27], B=London_births_vacc, N=N, inits=list(Snull=Dc[1]+ Smean[which(llik==min(llik))], Inull=Ic[1]),type="stoc")
  simI_vacc[,i] <- sim$I                 # store the simualted time series
}
matplot(simI_vacc, type="l",lty=1,lwd=2, col = rgb(0,0,0,.1),add=T)           # plot using a semi-transparent line so we can still see the data

################################################################################
# Stop: Note that there is run to run variation 
################################################################################

################################################################################
# Consider the cases averted as the differences between the observed cases and the 
# simulated

sum(apply(simI_non[547:806,],1,mean))          # sum the mean of all stochastic runs without vaccination
                                             
sum(apply(simI_vacc[547:806,],1,mean))               # sum the mean of all stochastic runs with vaccination
sum(apply(simI_non[547:806,],1,mean)) - sum(apply(simI_vacc[547:806,],1,mean))  # mean impact is the difference

################################################################################
# Stop: This doesn't account for the uncertainty in the projected time series
################################################################################

################################################################################
# Recall that the parameters of the TSIR model are themselves uncertain. So the 
# variation we've seen so far ONLY reflects the randomness in transmission from step to step
# but doesn't reflect the uncertainty in the paramters themselves. 


################################################################################
# To account for parameter uncertainty, we can draw separate values of the transmission 
# parameters. 
################################################################################
# Revisit the plot of the fitted transmission parameters
# this is just the code from above
matplot(x=c(1:26), y=cbind(beta,ubeta,lbeta) ,xlab="Biweek", ylab=expression(beta),pch=NA)    # create a plotting window 
points(x=c(1:26), y=beta, pch=19)                                                             # plot mean beta   
points(x=c(1:26), y=ubeta, pch="-")                                                           # plot upper bound beta
points(x=c(1:26), y=lbeta, pch="-")                                                           # plot lower bound beta
segments(x0=1:26,y0=lbeta,x1=1:26,y1=ubeta,lty=1,col=1)                                       # plot vertical bars for confidence bounds

# So within the confidence bounds there are multiple supported possible values of the transmission rate
# this implies that there is additional uncertainty in BOTH the 

###############################################################################
# Now, for every simulation run in nsim, we can draw random values of the transmission
# parameters from the confidence bounds This is called bootstrapping and the variation
# in the time series will include both the random draws of the parameters AND the
# stochastic projections conditional on each draw.

London_births_non <- c(meas$B,London_births)
London_births_vacc <- c(meas$B,London_births * (1-vaccination_coverage))

nsim <- 1000                        # number to simulate
simI_non <- matrix(NA,806,nsim)         # storage for each simulation
for(i in 1:nsim){                    # simulate nsim realizations
  beta_i <- runif(1:26,min=lbeta,max=ubeta)  # make a random draw from wthin the confidence bounds
  sim=SimTsir2(beta=beta_i, alpha=glmfit$coef[27], B=London_births_non, N=N, inits=list(Snull=Dc[1]+ Smean[which(llik==min(llik))], Inull=Ic[1]),type="stoc")
  simI_non[,i] <- sim$I                 # store the simualted time series

  # note that we draw the random values of the transmission parameter and simulate a realization of the non vaccination and the 
  # vaccination scenarios conditional on that draw. This assures that, for example, the same distribution of random draws 
  # from high and low values of the transmission parameters are compared against each other; AND that when we calculate the difference
  # in the number of cases in the non-vaccinated counter-factual and the vaccinated simulation, that we do so conditional on the 
  # same parameter draw in each.
  
  sim=SimTsir2(beta=beta_i, alpha=glmfit$coef[27], B=London_births_vacc, N=N, inits=list(Snull=Dc[1]+ Smean[which(llik==min(llik))], Inull=Ic[1]),type="stoc")
  simI_vacc[,i] <- sim$I                 # store the simualted time series
  }
# plot the time series again
matplot(simI_non, type="l",lty=1,lwd=2, col = rgb(1,0,0,.1), xlab="time", ylab="")           # plot using a semi-transparent line so we can still see the data
matplot(simI_vacc, type="l",lty=1,lwd=2, col = rgb(0,0,0,.1),add=T)           # plot using a semi-transparent line so we can still see the data

# Take the difference between the simulation without vaccination and the simulation with vaccination and plot a histogram of the
# difference for the first 5 years after vaccine introduction. Recall that vaccination was introduced after year 22. So consider 
# the sum of cases during years 22 - 26

years <- rep(1:31,each = 26)                   # make indices for each of the 31 years that we've simulated so it's easy to select them
indices <- which(years >= 22 & years <= 26)    # the indices that refer to years 22-26

cases_averted <- apply(simI_non[indices,],2,sum) - apply(simI_vacc[indices,],2,sum)      # calculate the difference between the no vaccination and vaccination scenarios
hist(cases_averted, xlab = "cases averted", main = "distribution of cases averted")                   # Plot the histogram of differences 

################################################################################
# Stop: Note that we've introduced vaccine at low levels. Even though we know from the model that vaccination 
# has to be protective (there is no uncertainty about efficacy or coverage), There ARE individual simulations 
# over the short term where the impact, in terms of cases averted, can be very small. Did any of you generate 
# simulations for which the impact was negative? How could that be?
################################################################################

# Now do the same comparison of cases averted over the full period of simulated vaccine introduction
indices <- which(years >= 22 & years <= 31)    # the indices that refer to years 22-26

cases_averted <- apply(simI_non[indices,],2,sum) - apply(simI_vacc[indices,],2,sum)      # calculate the difference between the no vaccination and vaccination scenarios
hist(cases_averted, xlab = "cases averted", main = "distribution of cases averted")                   # Plot the histogram of differences 

################################################################################
# Stop: What is different about this distribution of cases averted over 10 years compared to 
# the sum of impact over just the first 3 years
################################################################################


