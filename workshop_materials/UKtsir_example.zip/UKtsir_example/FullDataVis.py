""" FullDataVis.py

Visualize the time series data as well as the age distributions. """
## Standard imports
import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

## Custom global matplotlib parameters
## see http://matplotlib.org/users/customizing.html for details.
plt.rcParams["font.size"] = 20.
plt.rcParams["font.family"] = "serif"
plt.rcParams["font.serif"] = ["Garamond","Time New Roman"]
plt.rcParams["axes.formatter.use_mathtext"] = True
plt.rcParams["mathtext.fontset"] = "cm"

## Palette
colors = ["#DF0000","#00ff07","#0078ff","#BF00BA"]

def axes_setup(axes):
	axes.spines["left"].set_position(("axes",-0.025))
	axes.spines["top"].set_visible(False)
	axes.spines["right"].set_visible(False)
	return axes

if __name__ == "__main__":

	## Get the dataset from CSV
	df = pd.read_csv("UK_measles_data.csv",
					 index_col=0)
	print(df)

	## Make a full figure for everything
	fig = plt.figure(figsize=(12,6))
	case_ax = axes_setup(fig.add_subplot(2,1,(1,1)))
	birth_ax = axes_setup(fig.add_subplot(2,1,(2,2)))
	
	## Plot the cases
	case_ax.grid(color="grey",alpha=0.2)
	case_ax.plot(df["cases"]/1000,lw=3,color=colors[2])
	case_ax.set_ylim((0,None))
	case_ax.set_ylabel(r"Cases ($\times$1k)")
	case_ax.set_xticks(np.arange(0,len(df)+1,26*4))
	case_ax.set_xticklabels((np.arange(0,len(df)+1,26*4)/26 + 1944).astype(int))
	
	## And the yearly births
	birth_ax.grid(color="grey",alpha=0.2)
	birth_ax.plot(26*df["births"]/1000,lw=3,color=colors[0])
	birth_ax.set_ylabel(r"Births ($\times$1k)")
	birth_ax.set_xticks(np.arange(0,len(df)+1,26*4))
	birth_ax.set_xticklabels((np.arange(0,len(df)+1,26*4)/26 + 1944).astype(int))

	## Details
	fig.tight_layout()
	fig.savefig("_plots\\full_data_vis.png")


	plt.show()